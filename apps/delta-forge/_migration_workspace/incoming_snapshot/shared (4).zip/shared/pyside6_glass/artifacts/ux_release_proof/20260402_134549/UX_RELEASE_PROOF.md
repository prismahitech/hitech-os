# UX Release Proof

- Generated UTC: 2026-04-02T19:45:56.179105+00:00
- Passed: True
- Sacred contract digest: `a8f63aee9571d67e`
- Baseline version: `v1`
- Baseline digest: `2ced8062cf3db7df`

## Session Results
- `startup_blank_workspace`: PASS (events=2 checkpoints=1 severity=blocker)
- `picker_search_and_category`: PASS (events=5 checkpoints=1 severity=major)
- `add_to_current_tab`: PASS (events=6 checkpoints=1 severity=blocker)
- `open_in_new_tab`: PASS (events=5 checkpoints=1 severity=blocker)
- `drag_panel_cross_slot`: PASS (events=4 checkpoints=1 severity=blocker)
- `resize_panel_and_clamp`: PASS (events=4 checkpoints=1 severity=blocker)
- `clone_reset_isolation`: PASS (events=6 checkpoints=2 severity=blocker)
- `data_runtime_probe_states`: PASS (events=5 checkpoints=1 severity=blocker)

## Comparator
- Passed: True
- Max severity: informational
- Diff count: 0
- Severity counts: {'blocker': 0, 'major': 0, 'minor': 0, 'informational': 0}

## Capability Delta
- Total capabilities: 100
- Solid: 93
- Improved partial: 0
- Partial: 7
- Deferred: 0

## Baseline
- Semantic baseline: `F:\repos\hitech-os\forgeos\shared\pyside6_glass\baselines\ux_release_proof\v1\semantic_baseline.json`
- Visual baseline manifest: `F:\repos\hitech-os\forgeos\shared\pyside6_glass\baselines\ux_release_proof\v1\visual_baseline_manifest.json`
- Refreshed baseline this run: `False`

## Artifacts
- `golden_sessions_summary.json`
- `comparison_report.json`
- `capability_matrix_delta.json`
- `semantic_run_payload.json`
- `sessions/*` (manifests, events, checkpoints, screenshots)
