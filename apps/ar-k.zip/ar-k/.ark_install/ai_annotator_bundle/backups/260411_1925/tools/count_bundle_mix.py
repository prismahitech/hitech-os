from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path

IGNORED_DIRS = {'__pycache__', '.pytest_cache', '.mypy_cache'}
IGNORED_SUFFIXES = {'.pyc', '.pyo'}


def _visible_files(root: Path) -> list[Path]:
    items: list[Path] = []
    for path in root.rglob('*'):
        if not path.is_file():
            continue
        if any(part in IGNORED_DIRS for part in path.parts):
            continue
        if path.suffix in IGNORED_SUFFIXES:
            continue
        items.append(path)
    return items


def inspect_directory(root: Path) -> dict[str, object]:
    files = _visible_files(root)
    py_files = [path for path in files if path.suffix == '.py']
    return {
        'mode': 'directory',
        'path': str(root),
        'file_count': len(files),
        'py_count': len(py_files),
        'non_py_count': len(files) - len(py_files),
        'py_ratio': round((len(py_files) / len(files)) if files else 0.0, 6),
        'compressed_size_bytes': None,
    }


def inspect_zip(path: Path) -> dict[str, object]:
    with zipfile.ZipFile(path) as zf:
        entries = [
            info for info in zf.infolist()
            if not info.is_dir() and '/__pycache__/' not in info.filename and not info.filename.endswith(('.pyc', '.pyo'))
        ]
        py_entries = [info for info in entries if info.filename.endswith('.py')]
        return {
            'mode': 'zip',
            'path': str(path),
            'file_count': len(entries),
            'py_count': len(py_entries),
            'non_py_count': len(entries) - len(py_entries),
            'py_ratio': round((len(py_entries) / len(entries)) if entries else 0.0, 6),
            'compressed_size_bytes': path.stat().st_size,
            'top_level_entries': sorted({item.filename.split('/')[0] for item in entries}),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('target')
    ns = parser.parse_args()
    target = Path(ns.target)
    data = inspect_zip(target) if target.suffix == '.zip' else inspect_directory(target)
    print(json.dumps(data, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
