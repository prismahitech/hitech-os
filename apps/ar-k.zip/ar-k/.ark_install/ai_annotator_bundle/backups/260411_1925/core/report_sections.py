"""Exact closeout report order for the AI Annotator gold-finish pass."""

from __future__ import annotations

REPORT_SECTIONS = [
    "1. STATUS",
    "2. ROOT CAUSE / DRIFT REMOVED",
    "3. FILES CREATED / MODIFIED / DELETED",
    "4. COMMANDS RUN",
    "5. CANON ALIGNMENT",
    "6. VALIDATION RESULTS",
    "7. RISKS",
    "8. NEXT STEPS",
]
