
from __future__ import annotations

import unittest
from pathlib import Path

from tools.count_bundle_mix import inspect_directory


class CountBundleMixTests(unittest.TestCase):
    def test_directory_py_ratio_exceeds_threshold(self) -> None:
        root = Path(__file__).resolve().parents[1]
        data = inspect_directory(root)
        self.assertGreaterEqual(data['py_ratio'], 0.9)
        self.assertGreater(data['py_count'], data['non_py_count'])


if __name__ == '__main__':
    unittest.main()
