"""Executable advisory-boundary checks."""
