"""Safe Ignore Cases corpus."""
