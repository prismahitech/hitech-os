"""Ambiguity Cases corpus."""
