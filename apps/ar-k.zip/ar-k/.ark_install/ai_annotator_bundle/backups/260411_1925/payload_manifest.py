"""Generated payload manifest for the homologated AI Annotator bundle."""

from __future__ import annotations

PAYLOAD_MANIFEST = {
  'FINAL_REPORT.md': {
    "sha256": 'ac571f6eb00a71a30fb35c3894204b53851523ca9067b801f23548aeab5aadd8',
    "size": 4103
  },
  '__init__.py': {
    "sha256": 'a14ade017172bbc84e6c1f362572d4283ddb10a8d6cbcde482dccc27eaf6414f',
    "size": 62
  },
  'ai_annotator_installer.py': {
    "sha256": '38d5b458d11ddc3e857ae83dc413090efab9fa3706f232d0d830b31b3811cb96',
    "size": 8094
  },
  'checks/__init__.py': {
    "sha256": 'b0a6d1295e59b1ca6b9337890fb2bc6a69f741448081e0b7d23ff5e7483a377e',
    "size": 43
  },
  'checks/advisory_only_checks.py': {
    "sha256": '4d0e6985660bd837e1a4b52806e95a2a70d7f94d76f317a7a8a603722e08b5ba',
    "size": 1100
  },
  'checks/annotation_contract_checks.py': {
    "sha256": '1e30bf48851edc247ccf1bd04e2da12e4698561ad23199ff578598e31acb74fe',
    "size": 1176
  },
  'checks/authoritative_override_checks.py': {
    "sha256": 'afea02ab987681dbcfb989789eb61f67024bf6ad6ac7eb767196d7fe863f77ee',
    "size": 1257
  },
  'checks/path_exclusion_checks.py': {
    "sha256": 'c8703dec6cf604c7af8c877d3d226b8ee84dda7f648757fd39be54da9d8be396',
    "size": 842
  },
  'checks/promotion_checks.py': {
    "sha256": 'b7c49f9d4f18de6e30dc63c4eeee3f1f79fd568eba1d61889a7c63a940b8edd9',
    "size": 792
  },
  'checks/registry_index_shim_checks.py': {
    "sha256": 'dda9d0ae29ed86788584931f6bc53f4346bbcc02538128747a496487821970e6',
    "size": 738
  },
  'core/__init__.py': {
    "sha256": '7663d90b927f32ef90fb43aee87086bbdc6eb75f8f0ff22df8cfdd52cbe93d73',
    "size": 60
  },
  'core/bundle_constants.py': {
    "sha256": 'ef3688860a202981df861505a6c46049e420d23a915f48ae16135d440d01260a',
    "size": 2736
  },
  'core/case_loader.py': {
    "sha256": '2e29328a27b587cf2c35dfeb8ed2d98b8186cb0bc4458fd0355fe4bbd9941b27',
    "size": 497
  },
  'core/case_models.py': {
    "sha256": '795647627e5f3bd5b3d443464ca933bee56632d8f145fefc605eb57aa1a514d8',
    "size": 439
  },
  'core/example_builder.py': {
    "sha256": '423de72005d919e56fbcbec8ed9b61c9a9cffee9f7ec901b599b18c3f6467cea',
    "size": 2971
  },
  'core/index_compat.py': {
    "sha256": '05f4ff0040610e18b1a4da57e9abcdc0bc78e6002a429ab2a3b1c7a7645ff4b6',
    "size": 1339
  },
  'core/log_utils.py': {
    "sha256": 'bc127400f6ede2a3f11b69d7d919fcfbbe2fe6ec53f75c973b294e0159f4c939',
    "size": 487
  },
  'core/manifest_utils.py': {
    "sha256": 'bf52af7d56ebac8691eea5469ec6ef47baee91dd34ca961056a65103cba46603',
    "size": 409
  },
  'core/path_policy.py': {
    "sha256": 'ef27ff78c7f7fb2534974fe934b680b64623836a202abbe70bbfc54507a6361b',
    "size": 1801
  },
  'core/reference_snapshot.py': {
    "sha256": 'cf2306808055b2867c4ac1fbc20f892687717132df032084813770e88b0f143d',
    "size": 15742
  },
  'core/report_sections.py': {
    "sha256": '09db0679176baa1f2636df4c39b69fe19107fc2258102675c066058548877663',
    "size": 346
  },
  'core/system_map.py': {
    "sha256": '521f228f99be656dfdec0f5268a7bc69bfc28f2c73246e396e9cce8684fa5794',
    "size": 2647
  },
  'core/tool_contract.py': {
    "sha256": 'f7813d3481a6baffae14a3dc6258390727b7ed687fdcc403534b58b48a9e1e3d',
    "size": 3298
  },
  'core/write_limits.py': {
    "sha256": '08cc4ad686637b73aff8fc9fba9e39f6a9cc2e261bd412f8b6678edff0b3eb53',
    "size": 2377
  },
  'corpora/__init__.py': {
    "sha256": '225628412a93a40f49edc4b627c49e017b6f1c4a15bcde919d6e9d7017bd9a5e',
    "size": 55
  },
  'corpora/advisory_cases/__init__.py': {
    "sha256": '78777967fbb3e11aefa46696402291e20bd9f31820ee1ccbb29dddfc5a808d62',
    "size": 29
  },
  'corpora/advisory_cases/ann_adv_001.py': {
    "sha256": '2b5eb0d63eeca0d5316e93497481d9e7a78022da9627bbdd21857ac7d18a2675',
    "size": 3334
  },
  'corpora/advisory_cases/ann_adv_002.py': {
    "sha256": '5f1f726b97e996190b8e42fe5287cc740777ac5ad34eca55a1bb0e6b86527e5e',
    "size": 3363
  },
  'corpora/advisory_cases/ann_adv_003.py': {
    "sha256": 'e7f609b6917a181e44a3167ae93f1b74875e72022de8a94fcf3fbb96a38e13ab',
    "size": 3314
  },
  'corpora/advisory_cases/ann_adv_004.py': {
    "sha256": '2416ec19fbbaa2a98a6ee91c220a6ac3e988e4541a2f03ecf3c2c102daaa5192',
    "size": 3367
  },
  'corpora/advisory_cases/ann_adv_005.py': {
    "sha256": 'bc011afaea4d7b2ebe58297bd80a2d65c7837a928f607336f724d1007bdbd6c6',
    "size": 3444
  },
  'corpora/advisory_cases/ann_adv_006.py': {
    "sha256": '8a43b98a8c26c0c0c8e2f3e53e3fa8ad1cf90fbd14802521bcd0dc3955ad740c',
    "size": 3335
  },
  'corpora/advisory_cases/ann_adv_007.py': {
    "sha256": '5c8fe4118ec4e11d259bd4ee30278a650321fd4faba4f8380ea3ffabe27c9337',
    "size": 3364
  },
  'corpora/advisory_cases/ann_adv_008.py': {
    "sha256": 'edc16edf62f0e07bd32bd892e241586678180481cfaf94ead79f621db3f7db0a',
    "size": 3281
  },
  'corpora/advisory_cases/ann_adv_009.py': {
    "sha256": 'bc688596a7666901db62db47d2b243e5266f3e5d87d5c922bc86a175fbf4194f',
    "size": 3382
  },
  'corpora/advisory_cases/ann_adv_010.py': {
    "sha256": 'fb07007be699252244c98b9421bfa58e3041664f96f77a275a4ccbb35df76e02',
    "size": 3326
  },
  'corpora/advisory_cases/ann_adv_011.py': {
    "sha256": 'a1ab1439294235ca10a13550ca076003aa51337902c6379ae2759bddd8356036',
    "size": 3451
  },
  'corpora/advisory_cases/ann_adv_012.py': {
    "sha256": 'cc8814c3d043b6ab11eca9cfc49840f48db6a7233f6c13d241e54887d70c4369',
    "size": 3316
  },
  'corpora/advisory_cases/ann_adv_013.py': {
    "sha256": '388dd2518ffe116def1ae7ce147461618b91b872f3feb4ab1d37650e1f5e41c4',
    "size": 3395
  },
  'corpora/advisory_cases/ann_adv_014.py': {
    "sha256": '21e5548359900bf7152d442f21ab2b545842b7bc39f4a00bbdb7d9d14e7f14a0',
    "size": 3360
  },
  'corpora/advisory_cases/ann_adv_015.py': {
    "sha256": 'e41b6bcd09820303b10ca12b493de6fe77acb09f9589d14961472d4388ce7b99',
    "size": 3346
  },
  'corpora/advisory_cases/ann_adv_016.py': {
    "sha256": 'e952843f66c1b2e910098acedce9087c11aa6aa30264f3a7cb6b291da6444d83',
    "size": 3322
  },
  'corpora/advisory_cases/ann_adv_017.py': {
    "sha256": '13e33f24548b42f33919b2f8a1ec016f6d5ccf3ca80233a55f7caf8b88997f0e',
    "size": 3433
  },
  'corpora/advisory_cases/ann_adv_018.py': {
    "sha256": '145b1bcf48b5179f84ba5401bf4759211f47282303145ba935f9a60e17bd6b7c',
    "size": 3314
  },
  'corpora/advisory_cases/ann_adv_019.py': {
    "sha256": '210279b6ac1c3e0644d9da7959c7672eed10928f3671d90e0481ae654cd09937',
    "size": 3357
  },
  'corpora/advisory_cases/ann_adv_020.py': {
    "sha256": '6deadd502f1f503c7ded76f2abb25c0e5b3dbf2b26b9d40227c28e353a425055',
    "size": 3291
  },
  'corpora/advisory_cases/ann_adv_021.py': {
    "sha256": '66164704f39d6dfe6d9c2fb4763794444a826b9b48c37e9c6912c14eee89fa9f',
    "size": 3377
  },
  'corpora/advisory_cases/ann_adv_022.py': {
    "sha256": 'fe12cf402b31a713f6182ec447bbb7a6515438e3ddac7caee7be8b3bc32c0343',
    "size": 3355
  },
  'corpora/advisory_cases/ann_adv_023.py': {
    "sha256": '2e3218d15f47bf1a0c075251f3a26a04a5d38384b60bfab0c36a3269420ccc8b',
    "size": 3384
  },
  'corpora/advisory_cases/ann_adv_024.py': {
    "sha256": '55e34e8ad78c4c198b9d7414bcfd868581dd1fd4956f4656b8ca0806fd757024',
    "size": 3365
  },
  'corpora/advisory_cases/ann_adv_025.py': {
    "sha256": 'ef577cf677ef42e7be22960a9fab97aaccee4de987aa69de00e9bc56801dcf67',
    "size": 3351
  },
  'corpora/advisory_cases/ann_adv_026.py': {
    "sha256": '06bd67c77c556b84793b3a5bb790d72fa5532a24c18cc54f870662a8d6e6f427',
    "size": 3389
  },
  'corpora/advisory_cases/ann_adv_027.py': {
    "sha256": '983d1fddb5a7b5e487bdee8c1f3c468da52f69bcca0a9d6c0634c4ce3b6631cc',
    "size": 3437
  },
  'corpora/advisory_cases/ann_adv_028.py': {
    "sha256": 'aeedac5a1df6b24cd9c3e2bb49786eb882fc4196e52885ae4a5b63077329c8f8',
    "size": 3389
  },
  'corpora/advisory_cases/ann_adv_029.py': {
    "sha256": '242ea4519aeaf70a8aa85615ab31a284177fbd5d239f094cf07686f572563bfc',
    "size": 3348
  },
  'corpora/advisory_cases/ann_adv_030.py': {
    "sha256": 'c6516db9accee0916f5f08151980b7db0d53de8aa6e7631d099f2c0030ee81b4',
    "size": 3406
  },
  'corpora/advisory_cases/ann_adv_031.py': {
    "sha256": '9f7e4ac224002442887c7f5bc8da2cf44ab1b03373cb477657877f248396c88e',
    "size": 3348
  },
  'corpora/advisory_cases/ann_adv_032.py': {
    "sha256": 'd2b2c6185ff57232b51f7ed66610aefa483a5b9c32aef6c19bf8ea2095cd1d2b',
    "size": 3374
  },
  'corpora/advisory_cases/ann_adv_033.py': {
    "sha256": '6abf0f743a698e36f3ed3741191b4bae01d8a309af9a46283c209f96671dff13',
    "size": 3288
  },
  'corpora/advisory_cases/ann_adv_034.py': {
    "sha256": '0087abd8aa7fcbb7eee7ef98dfd99ab6a9ba7a71816467ae9f627c20a4a7e60e',
    "size": 3350
  },
  'corpora/advisory_cases/ann_adv_035.py': {
    "sha256": '9707d1f3c80e19862ab8f93b314f120a8dabc7589abbb174e93aa2a5c6868e25',
    "size": 3370
  },
  'corpora/advisory_cases/ann_adv_036.py': {
    "sha256": '7baf7a1f596b076f0f1b4a9663434de4121cbd02294e7c8ee1d11ab7bcebdd58',
    "size": 3306
  },
  'corpora/advisory_cases/ann_adv_037.py': {
    "sha256": '41d199eeeb1493ccd9ad97c7783ce831355b94b5b478211b6904b1678c65453d',
    "size": 3408
  },
  'corpora/advisory_cases/ann_adv_038.py': {
    "sha256": '22bf1937fd830cc3a0c644f83d47110fad6adbd6b3e337f7ca208b0bbcded84a',
    "size": 3408
  },
  'corpora/advisory_cases/ann_adv_039.py': {
    "sha256": '6b51aa3d67d548d59337d0c80c12262c617aeae6f2e5107ecd5df87a50691ceb',
    "size": 3382
  },
  'corpora/advisory_cases/ann_adv_040.py': {
    "sha256": '2e343a3dbda326d0d680e9a711e0d6cf2d276609c9eb8006525f00042589cb7a',
    "size": 3309
  },
  'corpora/advisory_cases/ann_adv_041.py': {
    "sha256": '3edae3c94bc0bad4dd1d9a7e1ae219e17d2b4f6223fbfc2c77ef780c1828ec41',
    "size": 3395
  },
  'corpora/advisory_cases/ann_adv_042.py': {
    "sha256": '4e329f8097911a1d885b870b66e59e696d9a4481d9f9938d3d0cd45e3b09dad3',
    "size": 3255
  },
  'corpora/advisory_cases/ann_adv_043.py': {
    "sha256": '9b7f4c1c468f60b4ee1dcb3fc4d2fbe6bc0995d5275c12fd2afe7fa3beaa3483',
    "size": 3385
  },
  'corpora/advisory_cases/ann_adv_044.py': {
    "sha256": '3a58c4e36ef2020b1e3961ccc0f997565b36a4c81d18b0f3dd7ad968005c6ba3',
    "size": 3377
  },
  'corpora/advisory_cases/ann_adv_045.py': {
    "sha256": 'c7843baf1a25b45233b9cd82605e0e575854117be49c2bc38aed6a3b99911793',
    "size": 3394
  },
  'corpora/advisory_cases/ann_adv_046.py': {
    "sha256": '048269f838a2d963bf83ff69ed01312d2ea8987e3668d3742f1cc09093a0fc8e',
    "size": 3283
  },
  'corpora/advisory_cases/ann_adv_047.py': {
    "sha256": 'e617d1cea95dc4e0d94166d633076ffc7c9573e56905b53e6e6be199d95aca06',
    "size": 3407
  },
  'corpora/advisory_cases/ann_adv_048.py': {
    "sha256": 'e4251d14854d99190eab7794d38b08485c93d1631550c43591aaea13877fe230',
    "size": 3321
  },
  'corpora/advisory_cases/ann_adv_049.py': {
    "sha256": 'f0f335b5c89141028309800c4567aaf527d74ffb8173f31df2dcef0acba070ea',
    "size": 3409
  },
  'corpora/advisory_cases/ann_adv_050.py': {
    "sha256": '74fa1e1bec7adb6eeac9a0f4f14a5cf2cc826e7f9c5f3317f822bc4a93816fc8',
    "size": 3328
  },
  'corpora/advisory_cases/ann_adv_051.py': {
    "sha256": '59474b64024f77709c08508c8cf24018186a3c9dd060710852135ed7dd3e4f62',
    "size": 3361
  },
  'corpora/advisory_cases/ann_adv_052.py': {
    "sha256": '85a084fb5dc4502a17f14a15508f9b9f4f8f9ab5a561d76998bfb94a4e1eb999',
    "size": 3340
  },
  'corpora/advisory_cases/ann_adv_053.py': {
    "sha256": '85565d92b1a2885c736040bd43133b376a408748cdcef177fba71605d2907699',
    "size": 3382
  },
  'corpora/advisory_cases/ann_adv_054.py': {
    "sha256": '14eb65acbdc1437c30df33a445513bce4d462854de5a63cc7d0380b090e63fb6',
    "size": 3282
  },
  'corpora/advisory_cases/ann_adv_055.py': {
    "sha256": 'c9657896a32b889638df29bc17ad09609b2d2edf074722cc815b4dc827ebc972',
    "size": 3355
  },
  'corpora/advisory_cases/ann_adv_056.py': {
    "sha256": 'faee148a0878f9d4901d6833cc631a251369e5c915bab8445c6a62ed4006e36b',
    "size": 3350
  },
  'corpora/advisory_cases/ann_adv_057.py': {
    "sha256": 'ada204e7ae8f2fd3c18180aa3f32595c4395e733f1e251ec4e7d552bf70f00ed',
    "size": 3345
  },
  'corpora/advisory_cases/ann_adv_058.py': {
    "sha256": 'ce7b15f08aef4402033c538a5a4669f3b9e7acc18d117c590a914c35044ad74b',
    "size": 3334
  },
  'corpora/advisory_cases/ann_adv_059.py': {
    "sha256": '964557a8863f13aca61e916c36dd992bae1a17d732c3109ddde92ca4ed96a3b0',
    "size": 3382
  },
  'corpora/advisory_cases/ann_adv_060.py': {
    "sha256": 'c912057ca65db261deac0a95dc1853a5814f5bdbef9b9ff1d58848a04a3f05fd',
    "size": 3263
  },
  'corpora/ambiguity_cases/__init__.py': {
    "sha256": 'f2c58dc036840c179bf5fd55aa802f5cab32e4d721aa44ee718ba73f5b2b704c',
    "size": 30
  },
  'corpora/ambiguity_cases/ann_amb_001.py': {
    "sha256": '31553d88fbb8a6aca1e36928924f3d7f854fa34095c4a0752b3627caa7662b85',
    "size": 3317
  },
  'corpora/ambiguity_cases/ann_amb_002.py': {
    "sha256": '060f8b44a5722a55527ee7c6567955dc3d273a3e98a9583f50e9328c039e4338',
    "size": 3422
  },
  'corpora/ambiguity_cases/ann_amb_003.py': {
    "sha256": '58972a395fe4d9e650c46e07ccad14be9f982e4c1b583b8857927e0ed5712693',
    "size": 3397
  },
  'corpora/ambiguity_cases/ann_amb_004.py': {
    "sha256": '54a2bb6afb20621b682438d11c44241ac3e947011a32b9f7816a68cf8145687d',
    "size": 3438
  },
  'corpora/ambiguity_cases/ann_amb_005.py': {
    "sha256": 'c086c7473f9989174d88ffb600ffa83578923b8d417c40a4472a007307cf045d',
    "size": 3421
  },
  'corpora/ambiguity_cases/ann_amb_006.py': {
    "sha256": 'c6b15120ccf7aa2894bdf4952af4a573c661639c96260c050c3c201053bf15fb',
    "size": 3380
  },
  'corpora/ambiguity_cases/ann_amb_007.py': {
    "sha256": 'c28c85b5b5d87a1d8584515cba1f25535e56040b7f9981736bce042968c62c4d',
    "size": 3391
  },
  'corpora/ambiguity_cases/ann_amb_008.py': {
    "sha256": 'b01d76b5416a73b3ef36282d304e18da5a56906e9f95482f92f1dbcbc91de683',
    "size": 3380
  },
  'corpora/ambiguity_cases/ann_amb_009.py': {
    "sha256": '76ec622aeb5cdcab4e4f4413ec69c42588f7b47f57a6b9503711e31fe179575c',
    "size": 3467
  },
  'corpora/ambiguity_cases/ann_amb_010.py': {
    "sha256": 'cb1a194e532e9eb9f93a9ee60742cf0cfc96ac702defd4dc547fd356f5e9abb7',
    "size": 3449
  },
  'corpora/ambiguity_cases/ann_amb_011.py': {
    "sha256": 'db54810b695d3e962c2b5a7e29e1d44f0ffa5fd24ac5c48813dfa448650e004e',
    "size": 3362
  },
  'corpora/ambiguity_cases/ann_amb_012.py': {
    "sha256": '14cfa46c44854e72b7f269e0955734f69a185ea77dff918efab519164431261b',
    "size": 3441
  },
  'corpora/ambiguity_cases/ann_amb_013.py': {
    "sha256": 'b6e18fcbfda112fff6e7aee31aa6899db645365eed4d1ed4134085257692be09',
    "size": 3454
  },
  'corpora/ambiguity_cases/ann_amb_014.py': {
    "sha256": '995e4ceab99ce25f77c8b461e589b42804f441db2f34edb94d1a014607f7b914',
    "size": 3443
  },
  'corpora/ambiguity_cases/ann_amb_015.py': {
    "sha256": 'ad09c48a2d222e6008715ab98a44e258439e70de1835beea42b7520bf0b81af6',
    "size": 3389
  },
  'corpora/ambiguity_cases/ann_amb_016.py': {
    "sha256": 'b90c0430a5018873f5277783cce0f47e8336040c8326a4ca41ec83f7281f727a',
    "size": 3359
  },
  'corpora/ambiguity_cases/ann_amb_017.py': {
    "sha256": '34a37aec4eb38c2ecc78b160a66e1c0681621d91a0494e9528ad3402835b670d',
    "size": 3448
  },
  'corpora/ambiguity_cases/ann_amb_018.py': {
    "sha256": 'a4818bfa154f9820be0dd11fc5a06edfde80d801f2f5d1a2b748f2fa51055227',
    "size": 3361
  },
  'corpora/ambiguity_cases/ann_amb_019.py': {
    "sha256": '57bbafbe5c384803461afcbe0942477b9d3a17dca8b03871a16abd8eff8a3b80',
    "size": 3390
  },
  'corpora/ambiguity_cases/ann_amb_020.py': {
    "sha256": '311852b48bd9569681dace897a00aabae9163ccd915d51c1c86668bebf9646ae',
    "size": 3434
  },
  'corpora/ambiguity_cases/ann_amb_021.py': {
    "sha256": 'd3a2e00600675cb09cb397edb7dc9bb7e6759a0065aaddb38fef19a7096f8119',
    "size": 3414
  },
  'corpora/ambiguity_cases/ann_amb_022.py': {
    "sha256": '185fcaf5c0b1bba29716bfe51078e1c34ed84214661d12f52929b8d2d838a03b',
    "size": 3484
  },
  'corpora/ambiguity_cases/ann_amb_023.py': {
    "sha256": '8dc26c9287fcb44a0e76d3e3222e11c710d42c8ceed4d620135e76e3b99af270',
    "size": 3337
  },
  'corpora/ambiguity_cases/ann_amb_024.py': {
    "sha256": '511d7ca7508fe66a03d332ebd25dcca94169fd148ef6362af2b782f875f8764f',
    "size": 3380
  },
  'corpora/ambiguity_cases/ann_amb_025.py': {
    "sha256": '4eac7e8905e6f6cd16a739086cfecdb869e95d93dd904a07c959e750f58b831d',
    "size": 3398
  },
  'corpora/ambiguity_cases/ann_amb_026.py': {
    "sha256": '3465c56b2808370497bb53e5d968badc032ac5eecb286128100b667c316f334c',
    "size": 3416
  },
  'corpora/ambiguity_cases/ann_amb_027.py': {
    "sha256": '545d63691216091cea08c53d931932f52cd8654a5a57ac1fae511edd90768a55',
    "size": 3342
  },
  'corpora/ambiguity_cases/ann_amb_028.py': {
    "sha256": 'bb963c53402593b759b1cf3df793b6a3823bd47401146ac619dac6166abae8dc',
    "size": 3346
  },
  'corpora/ambiguity_cases/ann_amb_029.py': {
    "sha256": '1a8b58bf7f5280085209f1315c167aee7ad70cb347f91e0622ef20d14acc2041',
    "size": 3423
  },
  'corpora/ambiguity_cases/ann_amb_030.py': {
    "sha256": 'ceed59336b5ea8cd9ca71a3b5718c9237d017105ca131e877ba76b81ba9adf5a',
    "size": 3505
  },
  'corpora/ambiguity_cases/ann_amb_031.py': {
    "sha256": '9fed797d505978fdfceb816cccbf5fe98843ce85899c83db5f17263157e9760d',
    "size": 3321
  },
  'corpora/ambiguity_cases/ann_amb_032.py': {
    "sha256": '3f84484be0ac8c96b73a7bbb9590b9765a5ef70538fd8f7a93e39bd73431004b',
    "size": 3457
  },
  'corpora/ambiguity_cases/ann_amb_033.py': {
    "sha256": '3814a3f125b9575c1b851ee4604408129201f7828eb9b2b09e4612625cbe33d0',
    "size": 3479
  },
  'corpora/ambiguity_cases/ann_amb_034.py': {
    "sha256": '46c21870719bd784576522db6c4b2da73570c35fb2b1a5667dd4bf5565b89f6b',
    "size": 3425
  },
  'corpora/ambiguity_cases/ann_amb_035.py': {
    "sha256": '9afe73cfff246505275cb828ceabb7e204f7460e5135e56c7a187208d2da3795',
    "size": 3433
  },
  'corpora/ambiguity_cases/ann_amb_036.py': {
    "sha256": '4edf0bd17d528a5903474a6782ca13e5dc5cffdb9dae3d10ef8e00d1c2d693fb',
    "size": 3441
  },
  'corpora/ambiguity_cases/ann_amb_037.py': {
    "sha256": 'c4e8487a4d68114b75620285c7022ce1465c1d8104f00a98b3745469597aafba',
    "size": 3393
  },
  'corpora/ambiguity_cases/ann_amb_038.py': {
    "sha256": '19b35d81f455da461a0f817e44f824541f16d482c1669f1bf4fa6a37883c7622',
    "size": 3473
  },
  'corpora/ambiguity_cases/ann_amb_039.py': {
    "sha256": 'a39151c55e1ca2e22dcaa649693f40bfc5cddeb9468a725db56b7bda19c49598',
    "size": 3383
  },
  'corpora/ambiguity_cases/ann_amb_040.py': {
    "sha256": 'a0dd3d152eeb01158b17cbcae66fb793085f651041fdfcc02da547b52b426659',
    "size": 3362
  },
  'corpora/ambiguity_cases/ann_amb_041.py': {
    "sha256": '77a75c14377160c8375cda0c2de591c3d2f315726e8898cf98482faf0a2f6854',
    "size": 3408
  },
  'corpora/ambiguity_cases/ann_amb_042.py': {
    "sha256": 'deca6e6b90c07854c6869063346880249f464e3dfa2d391ca97dabcb324d9207',
    "size": 3440
  },
  'corpora/ambiguity_cases/ann_amb_043.py': {
    "sha256": 'b50f9b0bfa077586c58f9c37f4a9a97c1ed4fc34f73f23b1f5987b916978045a',
    "size": 3456
  },
  'corpora/ambiguity_cases/ann_amb_044.py': {
    "sha256": '1296da53a643d419dafe7b949dcb418b9f1eb7f775656091cb598b50a2cc6e5c',
    "size": 3406
  },
  'corpora/ambiguity_cases/ann_amb_045.py': {
    "sha256": '76caf417911fe0c6825ce5a674305bf17866bb1de91c0958c4d6aa2268bf84c0',
    "size": 3365
  },
  'corpora/ambiguity_cases/ann_amb_046.py': {
    "sha256": '2f448559690b4633cccecdc41bb98853831801c25b58caacaced5ece6fb50bc3',
    "size": 3398
  },
  'corpora/ambiguity_cases/ann_amb_047.py': {
    "sha256": '5b79b0b2866827cd1e08f473d1a55e5fbaae0850538a69f40fac5c45cbd0bd9c',
    "size": 3390
  },
  'corpora/ambiguity_cases/ann_amb_048.py': {
    "sha256": '1aa9ffccacd3edfa4fed2c42f4afa3be3e4cf6bfb773ecbc6a4401b959208bd1',
    "size": 3480
  },
  'corpora/ambiguity_cases/ann_amb_049.py': {
    "sha256": '31d94fcfee3276898d5b9e31597843b2d363999cfc525a49ef1c2ea05721c3bc',
    "size": 3394
  },
  'corpora/ambiguity_cases/ann_amb_050.py': {
    "sha256": '0c1c25e5ec0094d7bd364956780c8e216f77c421ce131fa8bdda5f2aea39d070',
    "size": 3415
  },
  'corpora/ambiguity_cases/ann_amb_051.py': {
    "sha256": 'fc9d059c82382ea025df266a8e85ec49b0ed57a0d39d294500226cf4e2460764',
    "size": 3388
  },
  'corpora/ambiguity_cases/ann_amb_052.py': {
    "sha256": 'dd65b8f4a3fc6d08ba70b84e2a217e73752099879a014b3808363c55fe37ddd2',
    "size": 3317
  },
  'corpora/ambiguity_cases/ann_amb_053.py': {
    "sha256": '6aadb8b5de75d6aa0f62842160df381e464dfaa39149d38d615370fd1b138fa9',
    "size": 3469
  },
  'corpora/ambiguity_cases/ann_amb_054.py': {
    "sha256": 'a6295b76a3df5e4eb979ec5bc9398152c0b0a70d74de221177bc601414d0fcac',
    "size": 3483
  },
  'corpora/ambiguity_cases/ann_amb_055.py': {
    "sha256": '3423638c6966eaedd5acccf6604a4d756778df1a05574bcfe2348f7028189ab4',
    "size": 3380
  },
  'corpora/ambiguity_cases/ann_amb_056.py': {
    "sha256": 'd4b43b24a59410f6573d3328044ad6d58b272da58863c0302635f73c853171fc',
    "size": 3429
  },
  'corpora/ambiguity_cases/ann_amb_057.py': {
    "sha256": '30b06eaea62291163c33dbd49e1c168b18f47539f1771837f00b1080708656c3',
    "size": 3372
  },
  'corpora/ambiguity_cases/ann_amb_058.py': {
    "sha256": '7a4fdbca63080608bc00997c1a1a4569285a8ef9ace390dac5c458920b6b2982',
    "size": 3457
  },
  'corpora/ambiguity_cases/ann_amb_059.py': {
    "sha256": '2a836e0d7541ebb7106bea828e5f02e877b177fc7fc6fb5d0eb7f21f550e1132',
    "size": 3373
  },
  'corpora/ambiguity_cases/ann_amb_060.py': {
    "sha256": '2bcfc598ca3986df7de317ccedb49f87d6a7ed767f58cb0488783785b62d9e3f',
    "size": 3384
  },
  'corpora/case_index.py': {
    "sha256": '272a153c85209c9cb8893dab8dd661ad316299b8cbbd469eaebde7c8be8e192e',
    "size": 9161
  },
  'corpora/forbidden_override_cases/__init__.py': {
    "sha256": '4abc0b7155807e47aa1be4c67c9e2c9223ba852533923edb1e2432587a072537',
    "size": 39
  },
  'corpora/forbidden_override_cases/ann_for_001.py': {
    "sha256": 'afd8641c1461d937e31fb65305219749959e017ea0e4eae1677ec7599cd442eb',
    "size": 3453
  },
  'corpora/forbidden_override_cases/ann_for_002.py': {
    "sha256": '904562dc140f0d1b0c193e2ea32ee135925c570ada1f78e189165c7a1c2cbca1',
    "size": 3468
  },
  'corpora/forbidden_override_cases/ann_for_003.py': {
    "sha256": '931f7d94b4256cbbf27dfc2d7038e1a7bd36a09817f06d9c9c90b044a0d63f07',
    "size": 3359
  },
  'corpora/forbidden_override_cases/ann_for_004.py': {
    "sha256": '8197642f5e92eef498ec32fff492107b544b6072bf43c48b3c162d853a47f00b',
    "size": 3458
  },
  'corpora/forbidden_override_cases/ann_for_005.py': {
    "sha256": '633aa46a89e0dbe9bc3edd1180203102fece487c44a1baf54ce296c6cab77b60',
    "size": 3403
  },
  'corpora/forbidden_override_cases/ann_for_006.py': {
    "sha256": '7bb5ee9c2e86e3c0fd1a804a6851813d4da1aa5190825ac17a51066fda293c22',
    "size": 3330
  },
  'corpora/forbidden_override_cases/ann_for_007.py': {
    "sha256": '990c6c7f7a8c090fe52bd872e32f1523d1c25b88e73df665d79f4a62786ee585',
    "size": 3385
  },
  'corpora/forbidden_override_cases/ann_for_008.py': {
    "sha256": '2f44d484c7d72cc6624c628119dbb5a036f341da5d8e06812c2c4b7bee712c74',
    "size": 3458
  },
  'corpora/forbidden_override_cases/ann_for_009.py': {
    "sha256": '618b2bffb74caac4216441b3d4f3d59b2f7a95b09f1eaf5a14e2cef99f5e34cb',
    "size": 3399
  },
  'corpora/forbidden_override_cases/ann_for_010.py': {
    "sha256": 'b42a3215d163eab2dd7bf99dfa84b71538392ccdc97115eebf2f952036888046',
    "size": 3315
  },
  'corpora/forbidden_override_cases/ann_for_011.py': {
    "sha256": '78172dcd8da96037fcbad327bb563ceb3c76eae02d00a02521087d90f5f393a8',
    "size": 3414
  },
  'corpora/forbidden_override_cases/ann_for_012.py': {
    "sha256": '91c98cc25e308739a80e76771599e022d4c12a9fec528e92bc3b06043d1cd3f7',
    "size": 3441
  },
  'corpora/forbidden_override_cases/ann_for_013.py': {
    "sha256": '97b9b5517d4110c73e9596ebc5fffd76b4f09f05d4e7724d4278c5503450ffba',
    "size": 3380
  },
  'corpora/forbidden_override_cases/ann_for_014.py': {
    "sha256": '21c152bb15af8f573e0491ac9dcdf93d591c4f654a8d2a3ffde3c36371d700d2',
    "size": 3387
  },
  'corpora/forbidden_override_cases/ann_for_015.py': {
    "sha256": 'deac5389cdd4f4a4f8a254e87859e1d0b94562bc0553790d5e8236414298d625',
    "size": 3317
  },
  'corpora/forbidden_override_cases/ann_for_016.py': {
    "sha256": 'a97898eb1a6d539814a22915d25e5cd7f4f1de26654f9c7b893535430b0df81f',
    "size": 3325
  },
  'corpora/forbidden_override_cases/ann_for_017.py': {
    "sha256": 'ad9669863a6b10e723a275c886546287fb8ce1766c09fc2bfa5f797abc8fe5c6',
    "size": 3400
  },
  'corpora/forbidden_override_cases/ann_for_018.py': {
    "sha256": '8f1319a8e8744bc1250219a290ef7be7558ddf67dcbf5275fb972b10369e56f7',
    "size": 3331
  },
  'corpora/forbidden_override_cases/ann_for_019.py': {
    "sha256": 'e1c05869c13fca763cbe1e3db398f4f0b0da2eca1aa0c7fd5c71225cbe2fae27',
    "size": 3410
  },
  'corpora/forbidden_override_cases/ann_for_020.py': {
    "sha256": '2d53ecea7778f3e1856e54a74ecaa6b97075777f4bfca0c08c51d99b7bc0f0fa',
    "size": 3420
  },
  'corpora/forbidden_override_cases/ann_for_021.py': {
    "sha256": '45f2b128d349d32f860c45f1e77350434b9bafbe5c97298824b53099cf47803e',
    "size": 3342
  },
  'corpora/forbidden_override_cases/ann_for_022.py': {
    "sha256": 'dc7d11a381384174d7ebaa2b70265286779b89a0e655d682178fdd6c1f4bb474',
    "size": 3430
  },
  'corpora/forbidden_override_cases/ann_for_023.py': {
    "sha256": '4aded1437ad0915bc2db6ce8bcab2783f330218fb97abe740956c7e625f89f3d',
    "size": 3437
  },
  'corpora/forbidden_override_cases/ann_for_024.py': {
    "sha256": 'f0092c9bde8e52a8eb50a942db466968373d8dc9d2ea3a59c7b5c70eb33bc858',
    "size": 3390
  },
  'corpora/forbidden_override_cases/ann_for_025.py': {
    "sha256": '1cdf34ad471eb4ded2cac75220307995222e7d1f8d2610a94689cef5d1309343',
    "size": 3426
  },
  'corpora/forbidden_override_cases/ann_for_026.py': {
    "sha256": '093b9afb92254bff10d8817b72d5cb710e6ec1413acae7c9f4e43ef5acd9516b',
    "size": 3462
  },
  'corpora/forbidden_override_cases/ann_for_027.py': {
    "sha256": '421c6efbe4966a98fd4d4c6933094a58fa0de00c2ccddff5d7d82ddb38f3879a',
    "size": 3432
  },
  'corpora/forbidden_override_cases/ann_for_028.py': {
    "sha256": '5f346721d41f20799496aa27635b27b84015521957857254cf0398f9b79588cb',
    "size": 3356
  },
  'corpora/forbidden_override_cases/ann_for_029.py': {
    "sha256": 'eea1735bef04ec4066b7f9d60d48bc18a2dc5e436983b24e6368d1082e7a2912',
    "size": 3425
  },
  'corpora/forbidden_override_cases/ann_for_030.py': {
    "sha256": 'f43e8c3ade138f09deec19e322086a4bc80a50196abd9caea102f33245ba3df0',
    "size": 3393
  },
  'corpora/forbidden_override_cases/ann_for_031.py': {
    "sha256": '22a9c6b2dc9f3fcbec6ccddd5c6a9640ce3edd8bf2d786f89cbe05595b43a568',
    "size": 3501
  },
  'corpora/forbidden_override_cases/ann_for_032.py': {
    "sha256": '5a67af1bb0f6210ddb8d953fa02127c87808537b6cbf84feb49ac4d277982f1a',
    "size": 3419
  },
  'corpora/forbidden_override_cases/ann_for_033.py': {
    "sha256": 'd6dc3e9c67f812885a64f65df34a913009dcac3affbd36ba9a881a59a44effc3',
    "size": 3453
  },
  'corpora/forbidden_override_cases/ann_for_034.py': {
    "sha256": '83170cb617ea24453e6e9decea359f789470eccfec660ec149b49c82f2b1848b',
    "size": 3369
  },
  'corpora/forbidden_override_cases/ann_for_035.py': {
    "sha256": '493c63087d6820ca12a18b0e8bc6a922740c72f05cd7a86d58c04c8064a28297',
    "size": 3441
  },
  'corpora/forbidden_override_cases/ann_for_036.py': {
    "sha256": 'c1276dd81b595b2d1d3dfc2f69f3d3f05115dc7925a0071d099bd2d53bb5a91e',
    "size": 3479
  },
  'corpora/forbidden_override_cases/ann_for_037.py': {
    "sha256": '7a6b9527281d6f7bb4ed95c9600e94ea3365dc7bd916c8f73d38ea3135305b11',
    "size": 3509
  },
  'corpora/forbidden_override_cases/ann_for_038.py': {
    "sha256": 'da574ab4e4c5ecf6e6ed71039bfba7df753503ffe6c705fc0d87c74904c36667',
    "size": 3397
  },
  'corpora/forbidden_override_cases/ann_for_039.py': {
    "sha256": 'b52516324c30171d196c80d2cc9eaafe0a10a3aeb0a1b0f8af77f3a7befe9da9',
    "size": 3427
  },
  'corpora/forbidden_override_cases/ann_for_040.py': {
    "sha256": '5772608be7c002f92064be7b73b364a2c96428a59d83696bd7df6fb65eb8cc79',
    "size": 3374
  },
  'corpora/forbidden_override_cases/ann_for_041.py': {
    "sha256": 'd55ecee397deba6e235ea741355ab90119cc919186a12148f131310eb3bb39e8',
    "size": 3440
  },
  'corpora/forbidden_override_cases/ann_for_042.py': {
    "sha256": '7d59a7415b74d10d635c02b38aba8f247746be2a849fcb8d00ae7fa2959942b0',
    "size": 3380
  },
  'corpora/forbidden_override_cases/ann_for_043.py': {
    "sha256": '1f60ff344896f25b41870f2818acf9db20461b3ad5258a101b4051a14d02c601',
    "size": 3406
  },
  'corpora/forbidden_override_cases/ann_for_044.py': {
    "sha256": '0411c45b572e91797623a2c847a88e08a707196f8468bef0c6d29a43af7aa575',
    "size": 3448
  },
  'corpora/forbidden_override_cases/ann_for_045.py': {
    "sha256": '9110d43ca84e4c2942b611a52958dfd015991e34152ed7eaae6714bc378b72b7',
    "size": 3343
  },
  'corpora/forbidden_override_cases/ann_for_046.py': {
    "sha256": 'f8ff092ea560f1c199b0294335f016a6459637f87c00b5f988d632351a3848eb',
    "size": 3334
  },
  'corpora/forbidden_override_cases/ann_for_047.py': {
    "sha256": '1badf73ea1b2c81d90f13608dfd1568c8b031b9a9c5967da8dcb2ddc618de180',
    "size": 3430
  },
  'corpora/forbidden_override_cases/ann_for_048.py': {
    "sha256": '6f331db04c0d21e443ed3f976922c471d863547092dc72b1ffb577e873093f60',
    "size": 3424
  },
  'corpora/forbidden_override_cases/ann_for_049.py': {
    "sha256": 'b6bfbb15879db01c575fb8f04ac8570f63738e1ec5fb316b7fc6d2dde0df3fbe',
    "size": 3432
  },
  'corpora/forbidden_override_cases/ann_for_050.py': {
    "sha256": 'd730145698d7715de8fa6d52dc7396f210894293fe2de271840128f624bd45c4',
    "size": 3355
  },
  'corpora/safe_ignore_cases/__init__.py': {
    "sha256": '4af6b8ada928dd30469f7926d2d42cfe7a4ed74e5c4646d0f6ecfc6f2f7e6144',
    "size": 32
  },
  'corpora/safe_ignore_cases/ann_saf_001.py': {
    "sha256": 'b27546b9178df7276ad41f16355b4a542698cd4d5ae371d7898c85f34667edd4',
    "size": 3442
  },
  'corpora/safe_ignore_cases/ann_saf_002.py': {
    "sha256": '1cf538f938f637f52bbf7489778c63a62ef5d1dae203a2b62daa19afd1ead6d8',
    "size": 3453
  },
  'corpora/safe_ignore_cases/ann_saf_003.py': {
    "sha256": '53dfcfcbd07857a823193828dfdf6c46b252fb7c2d0a7bd85bd7c6e5767f9d4f',
    "size": 3409
  },
  'corpora/safe_ignore_cases/ann_saf_004.py': {
    "sha256": 'f86e3a5e199e83e28b150994d757d2b9ea9b86f4de441b892e3e5a0f9eeb8d33',
    "size": 3408
  },
  'corpora/safe_ignore_cases/ann_saf_005.py': {
    "sha256": '47cb17d886a0b279f123b04527a53b689e9839d9b730f27d7843e8495d5a4261',
    "size": 3356
  },
  'corpora/safe_ignore_cases/ann_saf_006.py': {
    "sha256": '6d6b2c4c98a097bff4e36634441e8dcc48be247677be1a8468f3f0f8d03ee832',
    "size": 3357
  },
  'corpora/safe_ignore_cases/ann_saf_007.py': {
    "sha256": '1796e052f3d2b1dcf2404c6405b399995c7a2a201b273e30fe21e624f585b529',
    "size": 3442
  },
  'corpora/safe_ignore_cases/ann_saf_008.py': {
    "sha256": 'cfb1ed0605b39757f90afaed6128ebfc59b91bad354f75d791e7f94ee3f8e28e',
    "size": 3377
  },
  'corpora/safe_ignore_cases/ann_saf_009.py': {
    "sha256": '4ff11fdc56eeb1600bb6a03df3337258814593dd6deae3ab56973821f96529a9',
    "size": 3359
  },
  'corpora/safe_ignore_cases/ann_saf_010.py': {
    "sha256": '21945568f6bcf0305fa71af6757c7935c193259a897ecde487360bf6f3f8f16e',
    "size": 3313
  },
  'corpora/safe_ignore_cases/ann_saf_011.py': {
    "sha256": 'ed26ceeff84b03ec4676a17fcb6a8736778917e049b83d7b770fb38374852ba9',
    "size": 3401
  },
  'corpora/safe_ignore_cases/ann_saf_012.py': {
    "sha256": 'c7098d97f6be82c3c01229df14bff1679e8d23e6b6526ae62399f955ca37e4c6',
    "size": 3458
  },
  'corpora/safe_ignore_cases/ann_saf_013.py': {
    "sha256": '74c0442ae60e0bbb4a846c418e060a0e5188d3af3be8bf4a9baf776306f4b4d1',
    "size": 3379
  },
  'corpora/safe_ignore_cases/ann_saf_014.py': {
    "sha256": '27aecd358b4b6bf8b87edbd329144f2c7cdc3a68a965626101993f59fad010d6',
    "size": 3410
  },
  'corpora/safe_ignore_cases/ann_saf_015.py': {
    "sha256": '7a6e475e1ca3ec7ff239a5a8c26623113d000380900d4e8b73f7673d46a75f89',
    "size": 3423
  },
  'corpora/safe_ignore_cases/ann_saf_016.py': {
    "sha256": '48e8499c782741e338d167fe99475a18b549e9d619c9508ed44b0bafef30e639',
    "size": 3371
  },
  'corpora/safe_ignore_cases/ann_saf_017.py': {
    "sha256": '5acba8aaa2ce608c0dd57be39979220150d9766e1e9eae250fd6e05e5faa9e48',
    "size": 3375
  },
  'corpora/safe_ignore_cases/ann_saf_018.py': {
    "sha256": 'b63431436690b12519386d9803f09cd3388c4f895ce9ff96a6db31fe1158446f',
    "size": 3394
  },
  'corpora/safe_ignore_cases/ann_saf_019.py': {
    "sha256": 'd5fb6b32f8e19a5e845f904f81560f3a706dfda953408c8cd603b6ea6e92778c',
    "size": 3381
  },
  'corpora/safe_ignore_cases/ann_saf_020.py': {
    "sha256": '6482cef994a3dd43d8968fe11db34414f497e63243eeab2f3f8b646867f5b3e2',
    "size": 3439
  },
  'corpora/safe_ignore_cases/ann_saf_021.py': {
    "sha256": 'e819fa0f14ea78c3907f4cff144b5804c45c93e0193b208b74bab1a1628585ee',
    "size": 3294
  },
  'corpora/safe_ignore_cases/ann_saf_022.py': {
    "sha256": '9ad6e4d06ed1e4cb436e870f27015e656901d0990323c8b41ff5e4c145d21927',
    "size": 3426
  },
  'corpora/safe_ignore_cases/ann_saf_023.py': {
    "sha256": '2591082410c9cea7941e46ef6095ad07473f32b97e3e1f4a1dabad9854acdf0c',
    "size": 3430
  },
  'corpora/safe_ignore_cases/ann_saf_024.py': {
    "sha256": 'd78af6ed7380278f1700eb0c5e7d15271714f9c4933ac8f4ebe9774f362a7df2',
    "size": 3477
  },
  'corpora/safe_ignore_cases/ann_saf_025.py': {
    "sha256": '4ae7d16f40401d602b2e65b9271ef1410462dfccfaba2ae48b7b7f28dfdae962',
    "size": 3369
  },
  'corpora/safe_ignore_cases/ann_saf_026.py': {
    "sha256": 'de5e93de19f7aa3808172407b43bf926f1b231013e8bb3467aa0883dadf93bd4',
    "size": 3399
  },
  'corpora/safe_ignore_cases/ann_saf_027.py': {
    "sha256": 'a7fd49973ed45220d4282876b2d04f7c4b7dd149f964cc54982150d1a54c7c03',
    "size": 3356
  },
  'corpora/safe_ignore_cases/ann_saf_028.py': {
    "sha256": 'e2d854379661620409127ca6ed5799ba0f7c8dc37cc67e9253a2de4dfccadb1e',
    "size": 3438
  },
  'corpora/safe_ignore_cases/ann_saf_029.py': {
    "sha256": 'bf9b598fcc868706e04003af3d601c42897739e8a961d4599b888f73bf3de791',
    "size": 3386
  },
  'corpora/safe_ignore_cases/ann_saf_030.py': {
    "sha256": 'd14731fb39eb26aacaaf1c6d54cf17f3389e60e08ff1183dedb924373e243cb8',
    "size": 3454
  },
  'tests/__init__.py': {
    "sha256": '0d30ca69cfadc62097e18e287a50e7f16eab91d0e135838da057973628a69f4d',
    "size": 58
  },
  'tests/test_advisory_boundaries.py': {
    "sha256": 'cdc088585232de4b022cae4cd75352967d09ce38370586607d017a0390cc2425',
    "size": 1609
  },
  'tests/test_case_inventory.py': {
    "sha256": '3c3389cc7a23e77422854e21a338b6edfce7ad955fdcbdae1fd2a35b9d0c5c7e',
    "size": 604
  },
  'tests/test_count_bundle_mix.py': {
    "sha256": 'f4a5624281bce480f978f16fcecab7d30435bcf90a60e59dac85f93c8609750f',
    "size": 506
  },
  'tests/test_generate_outputs.py': {
    "sha256": '240729fecbcaf947210daa04a125a5d784584a2073239967f1e329d43a55a0c1',
    "size": 1543
  },
  'tests/test_installer_contract.py': {
    "sha256": '453ca1bcbce23d883ceafaa059809327ae51662cb3d7ec6bdec560b84588cc5a',
    "size": 2760
  },
  'tests/test_query_index_shim.py': {
    "sha256": 'a0b5c4ae93ab097c5b59ae4e0eef5ea64e6d278b64419e0d3d13438f63025654',
    "size": 805
  },
  'tools/__init__.py': {
    "sha256": '73c0ccc7db0a74a0f093cec6309592fc46babdd6407d7b2400def5125977d1da',
    "size": 61
  },
  'tools/count_bundle_mix.py': {
    "sha256": '4b4020a4caef9b1382990ada8fe097b452ee62e9e5a1151e8bde111cba0e549e',
    "size": 2204
  },
  'tools/generate_example_outputs.py': {
    "sha256": '6ec63afe03fcf5879863f09326d44b77d9b008ac34b888774b09d786fa13d3f9',
    "size": 522
  },
  'tools/validate_ai_annotator_bundle.py': {
    "sha256": '9ad6cbb17a58f6eea94c8c27dee682e9222fc9a0a38cb6459166fd9f9a7619a5',
    "size": 3916
  },
}
