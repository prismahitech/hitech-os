# HITECH OS — Anti-Padding + Blinded Code Guardrails (LAW v1)

This pack installs a deterministic guardrail layer that blocks:
- LOC padding / metric gaming
- template explosion / duplicated-structure spam
- oversized files
- low-information (blinded) code expansions

## What it adds
- `tools/hos/guardrails/` Python package
- `tools/hos/guardrails/config/policy.json` default thresholds
- `tools/hos/guardrails/cli.py` CLI entrypoints
- `tools/hos/guardrails/validate_run.py` validates a Codex RUN_ID (per-worker)
- `tools/hos/guardrails/self_heal.py` loop: validate -> fail -> emit AMONESTACION -> attempt auto-fix (best-effort)
- optional wiring:
  - creates `tools/codex/dispatch/validator_ext.py` wrapper
  - patches `tools/codex/dispatch/validator.py` (if markers found) OR
  - patches `tools/codex/dispatch/run_iter.ps1` to call validator_ext after the run (idempotent, marker-based)

## Default policy (hard)
- max LOC per file: 3000
- max chars per file: 250000
- duplication% per file: <= 8%
- duplication% per worker output: <= 12%
- "blinded code" gate:
  - if LOC delta is large but behavioral-signal delta is tiny => BLOCK
  - signals: exports added, branch count delta, new test count delta, new module count

## Use
- Validate run:
  `python tools/hos/guardrails/cli.py validate-run --run-id <RUN_ID>`

- Self-heal (for agents):
  `python tools/hos/guardrails/cli.py self-heal --run-id <RUN_ID> --worker A_core`

See `docs/guardrails/ANTI_PADDING_LAW.md`.
