from __future__ import annotations
import os, json, argparse, subprocess, time, datetime
from typing import List, Optional
from .validate_run import find_repo_root
from .core import load_policy

def _run(cmd: List[str], cwd: str) -> int:
    p = subprocess.Popen(cmd, cwd=cwd)
    return p.wait()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--worker", required=True)
    ap.add_argument("--policy", default="tools/hos/guardrails/config/policy.json")
    ap.add_argument("--max-attempts", type=int, default=3)
    ap.add_argument("--fix-cmd", default="")
    args = ap.parse_args()

    repo = find_repo_root(os.getcwd())
    policy_path = os.path.join(repo, args.policy.replace("/", os.sep))
    policy = load_policy(policy_path)

    run_dir = os.path.join(repo, "tools", "codex", "runs", args.run_id, args.worker)
    os.makedirs(run_dir, exist_ok=True)

    log_path = os.path.join(run_dir, "SELF_HEAL_LOG.jsonl")

    for attempt in range(1, args.max_attempts+1):
        ts = datetime.datetime.utcnow().isoformat()+"Z"
        rc = _run(["python", os.path.join(repo, "tools", "hos", "guardrails", "validate_run.py"), "--run-id", args.run_id, "--policy", args.policy], cwd=repo)
        entry = {"ts": ts, "attempt": attempt, "validate_rc": rc}
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

        if rc == 0:
            print("SELF_HEAL: PASS ✅")
            return

        # AMONESTACION
        print("SELF_HEAL: FAIL ❌ — AMONESTACION: You produced padding/blinded code. You must refactor to reduce duplication, split oversized files, increase value density, and re-run validation.")
        # optional fixer hook (best-effort)
        if args.fix_cmd:
            print(f"SELF_HEAL: running fix command: {args.fix_cmd}")
            rc2 = _run(args.fix_cmd.split(" "), cwd=repo)
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"ts": ts, "attempt": attempt, "fix_rc": rc2}) + "\n")
        time.sleep(0.5)

    raise SystemExit("SELF_HEAL: exceeded max attempts; still blocked.")

if __name__ == "__main__":
    main()
