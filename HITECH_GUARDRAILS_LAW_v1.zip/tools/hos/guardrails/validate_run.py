from __future__ import annotations
import os, json, argparse, datetime
from typing import Dict, Any, List
from .core import load_policy, evaluate_worker, blinded_code_gate

WORKERS = ["A_core","B_tooling","C_features","D_validation","Z_aggregator"]

def find_repo_root(start: str) -> str:
    cur = os.path.abspath(start)
    for _ in range(40):
        if os.path.exists(os.path.join(cur, "pnpm-workspace.yaml")):
            return cur
        if os.path.isdir(os.path.join(cur, ".git")) and os.path.exists(os.path.join(cur, "package.json")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    raise SystemExit("Repo root not found. Run from inside repo.")

def validate_run(repo_root: str, run_id: str, policy_path: str) -> Dict[str,Any]:
    policy = load_policy(policy_path)
    run_dir = os.path.join(repo_root, "tools", "codex", "runs", run_id)
    if not os.path.isdir(run_dir):
        raise SystemExit(f"Run dir not found: {run_dir}")

    results: Dict[str,Any] = {"run_id": run_id, "timestamp": datetime.datetime.utcnow().isoformat()+"Z", "workers": {}, "blocked": False, "violations": []}

    for w in WORKERS:
        wdir = os.path.join(run_dir, w)
        if not os.path.isdir(wdir):
            continue
        rep = evaluate_worker(repo_root, run_dir, w, policy)
        bc = blinded_code_gate(rep, policy)
        if bc:
            rep.violations.append(bc)
        results["workers"][w] = {
            "totals": rep.totals,
            "violations": rep.violations,
            "files": [
                {
                    "path": os.path.relpath(f.path, repo_root).replace("\\","/"),
                    "loc": f.loc,
                    "chars": f.chars,
                    "duplication_pct": f.duplication_pct,
                    "exports": f.exports,
                    "branches": f.branches,
                    "is_test": f.is_test,
                } for f in rep.files
            ]
        }
        if rep.violations:
            results["violations"].extend(rep.violations)

    if results["violations"]:
        results["blocked"] = True
    return results

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--policy", default="tools/hos/guardrails/config/policy.json")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    repo = find_repo_root(os.getcwd())
    res = validate_run(repo, args.run_id, os.path.join(repo, args.policy.replace("/", os.sep)))
    out_path = args.out or os.path.join(repo, "tools", "codex", "runs", args.run_id, "GUARDRAILS_REPORT.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)
    if res["blocked"]:
        print(f"GUARDRAILS: BLOCKED. Report: {out_path}")
        raise SystemExit(2)
    print(f"GUARDRAILS: PASS. Report: {out_path}")

if __name__ == "__main__":
    main()
