from __future__ import annotations
import argparse, os, sys, subprocess

def main():
    ap = argparse.ArgumentParser(prog="hos-guardrails")
    sub = ap.add_subparsers(dest="cmd", required=True)

    v = sub.add_parser("validate-run")
    v.add_argument("--run-id", required=True)
    v.add_argument("--policy", default="tools/hos/guardrails/config/policy.json")

    s = sub.add_parser("self-heal")
    s.add_argument("--run-id", required=True)
    s.add_argument("--worker", required=True)
    s.add_argument("--policy", default="tools/hos/guardrails/config/policy.json")
    s.add_argument("--max-attempts", type=int, default=3)
    s.add_argument("--fix-cmd", default="")

    args = ap.parse_args()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    if args.cmd == "validate-run":
        cmd = [sys.executable, os.path.join(root, "tools", "hos", "guardrails", "validate_run.py"), "--run-id", args.run_id, "--policy", args.policy]
        raise SystemExit(subprocess.call(cmd, cwd=root))
    if args.cmd == "self-heal":
        cmd = [sys.executable, os.path.join(root, "tools", "hos", "guardrails", "self_heal.py"),
               "--run-id", args.run_id, "--worker", args.worker, "--policy", args.policy,
               "--max-attempts", str(args.max_attempts)]
        if args.fix_cmd:
            cmd += ["--fix-cmd", args.fix_cmd]
        raise SystemExit(subprocess.call(cmd, cwd=root))

if __name__ == "__main__":
    main()
