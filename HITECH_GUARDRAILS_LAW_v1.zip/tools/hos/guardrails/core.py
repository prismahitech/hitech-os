"""
HITECH OS Guardrails — Anti-Padding + Blinded Code (LAW v1)

Design goals:
- deterministic
- lightweight
- repo-local (no cloud)
- per-worker enforcement for Codex factory runs
"""

from __future__ import annotations

import os, re, json, hashlib, math
from dataclasses import dataclass
from typing import Dict, List, Tuple, Iterable, Optional, Any

_RE_EXPORT = re.compile(r'^\s*export\s+(?:type|interface|const|function|class|enum)\b', re.MULTILINE)
_RE_BRANCH = re.compile(r'\b(if|else if|switch|case|for|while|catch)\b')
_RE_TESTFILE = re.compile(r'(\.test\.(ts|tsx|js|jsx)|tests?/)', re.IGNORECASE)

def _sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def iter_files(repo_root: str, include_ext: List[str], exclude_dirs: List[str]) -> Iterable[str]:
    exset = set(exclude_dirs)
    for root, dirs, files in os.walk(repo_root):
        dirs[:] = [d for d in dirs if d not in exset]
        for fn in files:
            ext = os.path.splitext(fn)[1].lower()
            if ext in include_ext:
                yield os.path.join(root, fn)

def count_loc(text: str) -> int:
    # meaningful-ish LOC: non-empty
    return sum(1 for line in text.splitlines() if line.strip())

def compute_line_hashes(text: str) -> List[str]:
    # normalize whitespace to reduce cosmetic variance
    hashes = []
    for line in text.splitlines():
        ln = re.sub(r'\s+', ' ', line.strip())
        if not ln:
            continue
        hashes.append(_sha1(ln))
    return hashes

def rolling_window_hashes(line_hashes: List[str], window: int = 8) -> List[str]:
    if len(line_hashes) < window:
        return []
    out = []
    for i in range(0, len(line_hashes) - window + 1):
        out.append(_sha1("".join(line_hashes[i:i+window])))
    return out

@dataclass
class FileMetrics:
    path: str
    loc: int
    chars: int
    exports: int
    branches: int
    is_test: bool
    duplication_pct: float
    top_clone_groups: List[Tuple[str,int]]  # (window_hash, count)

def file_metrics(text: str, path: str) -> FileMetrics:
    loc = count_loc(text)
    chars = len(text)
    exports = len(_RE_EXPORT.findall(text))
    branches = len(_RE_BRANCH.findall(text))
    is_test = bool(_RE_TESTFILE.search(path.replace("\\","/")))
    line_hashes = compute_line_hashes(text)
    windows = rolling_window_hashes(line_hashes, window=8)
    freq: Dict[str,int] = {}
    for w in windows:
        freq[w] = freq.get(w, 0) + 1
    # A "duplicate" window = appears >=2
    dup_windows = sum(c for c in freq.values() if c >= 2)
    total_windows = max(1, len(windows))
    duplication_pct = (dup_windows / total_windows) * 100.0
    top = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:50]
    return FileMetrics(path=path, loc=loc, chars=chars, exports=exports, branches=branches, is_test=is_test,
                       duplication_pct=duplication_pct, top_clone_groups=top)

@dataclass
class WorkerReport:
    worker: str
    files: List[FileMetrics]
    totals: Dict[str, Any]
    violations: List[str]

def load_policy(policy_path: str) -> Dict[str, Any]:
    with open(policy_path, "r", encoding="utf-8") as f:
        return json.load(f)

def _rel(repo_root: str, p: str) -> str:
    try:
        return os.path.relpath(p, repo_root).replace("\\","/")
    except Exception:
        return p.replace("\\","/")

def _load_files_changed(worker_dir: str) -> List[str]:
    fp = os.path.join(worker_dir, "FILES_CHANGED.json")
    if not os.path.exists(fp):
        return []
    data = json.loads(read_text(fp))
    out: List[str] = []
    # accept multiple shapes
    if isinstance(data, dict):
        for k in ("added","modified","deleted","files","paths"):
            v = data.get(k)
            if isinstance(v, list):
                out.extend([str(x) for x in v])
    elif isinstance(data, list):
        out = [str(x) for x in data]
    # remove deletions if present as dict objects
    out2 = []
    for p in out:
        if not p or p.strip() == "":
            continue
        out2.append(p.replace("\\","/"))
    return sorted(set(out2))

def _candidate_repo_files(repo_root: str, worker_dir: str, policy: Dict[str,Any]) -> List[str]:
    # prefer FILES_CHANGED.json; fallback to scanning FILES/ snapshot
    changed = _load_files_changed(worker_dir)
    repo_paths = []
    for rel in changed:
        abs_path = os.path.join(repo_root, rel.replace("/", os.sep))
        if os.path.exists(abs_path) and os.path.isfile(abs_path):
            repo_paths.append(abs_path)
    if repo_paths:
        return repo_paths
    # fallback: use FILES snapshots (may contain copies)
    snap_dir = os.path.join(worker_dir, "FILES")
    if os.path.isdir(snap_dir):
        out = []
        for p in iter_files(snap_dir, policy["scan"]["include_ext"], policy["scan"]["exclude_dirs"]):
            out.append(p)
        return out
    return []

def evaluate_worker(repo_root: str, run_dir: str, worker: str, policy: Dict[str,Any]) -> WorkerReport:
    worker_dir = os.path.join(run_dir, worker)
    caps = policy["caps"]
    paths = _candidate_repo_files(repo_root, worker_dir, policy)
    metrics: List[FileMetrics] = []
    violations: List[str] = []
    total_loc = 0
    total_exports = 0
    total_branches = 0
    total_tests = 0

    for p in paths:
        try:
            txt = read_text(p)
        except Exception as e:
            violations.append(f"[{worker}] cannot read file: {_rel(repo_root,p)} :: {e}")
            continue
        m = file_metrics(txt, p)
        metrics.append(m)
        total_loc += m.loc
        total_exports += m.exports
        total_branches += m.branches
        total_tests += 1 if m.is_test else 0

        relp = _rel(repo_root, p)
        if m.loc > caps["max_loc_per_file"]:
            violations.append(f"[{worker}] MAX_LOC_PER_FILE violated: {relp} loc={m.loc} > {caps['max_loc_per_file']}")
        if m.chars > caps["max_chars_per_file"]:
            violations.append(f"[{worker}] MAX_CHARS_PER_FILE violated: {relp} chars={m.chars} > {caps['max_chars_per_file']}")
        if m.duplication_pct > caps["max_duplication_pct_per_file"]:
            violations.append(f"[{worker}] DUPLICATION_PER_FILE violated: {relp} dup%={m.duplication_pct:.2f} > {caps['max_duplication_pct_per_file']}")
        # clone explosion check
        big_groups = [g for g in m.top_clone_groups if g[1] >= 5]
        if big_groups and big_groups[0][1] > caps["max_top_clone_group"]:
            violations.append(f"[{worker}] CLONE_GROUP_SIZE violated: {relp} top_group={big_groups[0][1]} > {caps['max_top_clone_group']}")

    # worker-level duplication: aggregate window hashes across files
    all_windows: Dict[str,int] = {}
    for m in metrics:
        txt = read_text(m.path)
        lh = compute_line_hashes(txt)
        wh = rolling_window_hashes(lh, window=8)
        for w in wh:
            all_windows[w] = all_windows.get(w, 0) + 1
    dup = sum(c for c in all_windows.values() if c >= 2)
    total = max(1, sum(all_windows.values()))
    worker_dup_pct = (dup/total)*100.0
    if worker_dup_pct > caps["max_duplication_pct_per_worker"]:
        violations.append(f"[{worker}] DUPLICATION_PER_WORKER violated: dup%={worker_dup_pct:.2f} > {caps['max_duplication_pct_per_worker']}")

    totals = {
        "files_considered": len(metrics),
        "total_loc": total_loc,
        "total_exports": total_exports,
        "total_branches": total_branches,
        "test_files": total_tests,
        "duplication_pct_worker": worker_dup_pct
    }
    return WorkerReport(worker=worker, files=metrics, totals=totals, violations=violations)

def _behavioral_delta_index(totals: Dict[str,Any]) -> float:
    # crude behavioral signal: exports + branches + tests + new modules
    files = max(1, totals.get("files_considered", 1))
    exports = totals.get("total_exports", 0)
    branches = totals.get("total_branches", 0)
    tests = totals.get("test_files", 0)
    new_modules = files
    return float(exports + 0.25*branches + 2.0*tests + 0.5*new_modules)

def blinded_code_gate(report: WorkerReport, policy: Dict[str,Any]) -> Optional[str]:
    bc = policy.get("blinded_code", {})
    if not bc.get("enabled", True):
        return None
    loc = report.totals.get("total_loc", 0)
    if loc < 500:  # ignore tiny changes
        return None
    behavioral = _behavioral_delta_index(report.totals)
    ratio = behavioral / max(1.0, float(loc))
    if ratio < float(bc.get("min_behavioral_delta_ratio", 0.08)):
        return f"[{report.worker}] BLINDED_CODE suspected: behavioral/loc={ratio:.4f} < {bc.get('min_behavioral_delta_ratio')}"
    return None
