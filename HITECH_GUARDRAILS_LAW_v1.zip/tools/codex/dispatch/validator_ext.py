"""
validator_ext.py — Wrapper to enforce Anti-Padding LAW after existing guardrails.

Usage:
  python tools/codex/dispatch/validator_ext.py validate-guardrails --run-id <RUN_ID>
  python tools/codex/dispatch/validator_ext.py validate-anti-padding --run-id <RUN_ID>
"""
from __future__ import annotations
import os, sys, subprocess, argparse

def repo_root() -> str:
    cur = os.path.abspath(os.getcwd())
    for _ in range(40):
        if os.path.exists(os.path.join(cur, "pnpm-workspace.yaml")):
            return cur
        if os.path.isdir(os.path.join(cur, ".git")) and os.path.exists(os.path.join(cur, "package.json")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return os.path.abspath(os.getcwd())

def call(cmd, cwd):
    return subprocess.call(cmd, cwd=cwd)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["wait-done","validate-guardrails","validate-anti-padding"])
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()

    root = repo_root()
    base_validator = os.path.join(root, "tools", "codex", "dispatch", "validator.py")
    # Call the base validator if present for parity
    if os.path.exists(base_validator) and args.command in ("wait-done","validate-guardrails"):
        rc = call([sys.executable, base_validator, args.command, "--run-id", args.run_id], cwd=root)
        if rc != 0:
            return rc

    # Always enforce anti-padding on validate-guardrails too
    if args.command in ("validate-guardrails","validate-anti-padding"):
        anti = os.path.join(root, "tools", "hos", "guardrails", "validate_run.py")
        rc2 = call([sys.executable, anti, "--run-id", args.run_id], cwd=root)
        return rc2

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
