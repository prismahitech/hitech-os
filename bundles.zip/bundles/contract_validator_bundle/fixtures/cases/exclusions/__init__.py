"""Cases for exclusions."""
