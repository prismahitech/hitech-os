"""Cases for ownership."""
